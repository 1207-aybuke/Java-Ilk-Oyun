import java.awt.image.BufferedImage;

public class BoyutOku {

	//ok isaretinin bilgilerini girdik
	private BufferedImage okResmi;
	private int konumX;
	private int konumY;
	private boolean buyut;
	
	public BoyutOku(BufferedImage okResmi, int konumX, int konumY, boolean buyut) {
		//buaralarda this kullanmam�z�n nedeni diger class'lardaki �zelliklerle karismamasi icin
		this.okResmi = okResmi;
		this.konumX = konumX;
		this.konumY = konumY;
		this.buyut = buyut;
		
		//oklar�n koordinat bilgilerini belirlemek icin 
		if(konumY + okResmi.getWidth() > 540) {
			konumY= 540 - okResmi.getWidth();
		}
	}
	
	public BufferedImage getOkResmi() {
		return okResmi;
	}
	
	public int getKonumX() {
		return konumX;
	}
	
	public int getKonumY() {
		return konumY;
	}
	
	public void setKonumX(int konumX) {
		this.konumX = konumX;
	}
	
	public void setKonumY(int konumY) {
		this.konumY = konumY;
	}
	
	//pandan�n boyutunu ayarlamak icin
	public boolean Buyut() {
		return buyut;
	}
	
}
