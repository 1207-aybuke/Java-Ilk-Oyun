
import java.awt.Color;
import java.awt.HeadlessException;
import java.io.IOException;

import javax.swing.JFrame;

public class OyunEkrani extends JFrame {

	//basl�k olusturma kismi
	public OyunEkrani(String title) throws HeadlessException {
		super(title);
	}
	
	public static void main(String[] args) throws IOException {

		//basl�ga panda ismini verip nesne olusturduk
		OyunEkrani ekran = new OyunEkrani("PANDA");

		//ekran penceresini boyutland�rmada sikinti yasamamak icin
		ekran.setResizable(false);
	
		ekran.setSize(800, 630);
		ekran.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ekran.setBackground(Color.BLACK);	
		Oyun oyun = new Oyun();

		ekran.add(oyun);
		//oyun penceresini ortalamak icin
		ekran.setLocationRelativeTo(null);
		//oyun ekranina erisim saglamak icin
		ekran.setVisible(true);
		
		oyun.Baslat();
	}

}
